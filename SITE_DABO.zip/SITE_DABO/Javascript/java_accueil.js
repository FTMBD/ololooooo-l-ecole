/*let date = new Date();
let langue =  navigator.language;
let lien = document.getElementById("mail");*/

/*function objet(){
    if (langue==="fr"){
        let dateFr = date.getDate().toString().padStart(2,"0") + "-" + (date.getMonth()+1).toString().padStart(2,"0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();

        lien.href="mailto:fatima.dabo@etu.univ-poitier.fr?subject=Page chargé le : " + dateFr;
    }
    else {
        let dateEn = (date.getMonth() + 1).toString().padStart(2, "0") + "-" + date.getDate().toString().padStart(2, "0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();
        lien.href = "mailto:fatima.dabo@etu.univ-poitier.fr?subject=Page chargé le : " + dateEn;
    }
}
function sendEmail() {
    Email.send({
        To : 'fatimadabo@etu.univ-poitiers.fr',
        From : "sender@example.com",
        Subject : objet(),
    }).then(
        message => alert(message)
    );
}*/
/*
function sendEmail() {
//index.js
        Email.send({
            Host: "smtp.gmail.com",
            Username : "<sender’s email address>",
            Password : "<email password>",
            To : '<recipient’s email address>',
            From : "<sender’s email address>",
            Subject : "<email subject>",
            Body : "<email body>",
        }).then(
            message => alert("mail sent successfully")
        );
    }
    var link = "mailto:muusta45@gmail.com"
        + "&subject=" + encodeURIComponent("This is my subject")
        + "&body=" + encodeURIComponent(document.getElementById('myText').value)
    ;

    window.location.href = link;
}
*/


/*"use strict";

let date = new Date();
let langue =  navigator.language;
let lien = document.getElementById("mail");
functio
if (langue==="fr"){
    let dateFr = date.getDate().toString().padStart(2,"0") + "-" + (date.getMonth()+1).toString().padStart(2,"0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();

    lien.href="mailto:fatima.dabo@etu.univ-poitier.fr?subject=Page chargé le : " + dateFr;
}
else {
    let dateEn = (date.getMonth() + 1).toString().padStart(2, "0") + "-" + date.getDate().toString().padStart(2, "0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();
    lien.href = "mailto:fatima.dabo@etu.univ-poitier.fr?subject=Page chargé le : " + dateEn;
}*/







/*let s1 = document.createElement('link');
s1.type = 'text/css';
s1.rel = 'stylesheet';
s1.title = 'accueil';
s1.href = '../../styles/accueil.css';
document.head.appendChild(s1);

let s2 = document.createElement('link');
//let s2 = document.createElement('style');
//let s2: HTMLLinkElement = this.document.createElement('link')
s2.type = 'text/css';
s2.rel = 'alternate stylesheet';
s2.title = 'accueil_alternatif';
s2.href = '../../styles/accueil_alternatif.css';
document.head.appendChild(s2);*/

/*function setActiveStyleSheet(title) {
   // var i, a, main;
    var selectedSheet;
    var currentSheet;
    for(var i = 0; i < document.styleSheets.length; i++) {
        currentSheet = document.styleSheets[i];
        if(a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {
            a.disabled = true;
            if(a.getAttribute("title") == title) a.disabled = false;
        }
    }
}*/

function updatestyle() {

    var theme = document.getElementsByTagName('link')[0];
    if (theme.getAttribute('href') === '../../styles/accueil.css') {
        theme.setAttribute('href', '../../styles/accueil_alternatif.css');
    } else {
        theme.setAttribute('href', '../../styles/accueil.css');
    }
}
    /*let S = document.styleSheets;
if(S[1].disabled === true){
    S[0].disabled=true;
    S[1].disabled=false;
}
else{
    S[0].disabled=true;
    S[1].disabled=false;
}*/


    /*

        let S=document.styleSheets;

        alert(S[0].title);
        //alert(S[0].disabled);
        alert(S[1].title);
        //alert(S[1].disabled);


        if(S[0].disabled === true){
            S[0].disabled=false;
            S[1].disabled=true;
            //document.getElementById("alternatif").disabled=true;
        }
        else{
            S[0].disabled=true;
            S[1].disabled=false;
            //document.getElementById("alternatif").disabled=false;
        }*/
   // alert(S.length);

   /* if(S[0].disabled === true){
        alert("if");
        S[0].disabled=false;
        S[1].disabled=true;
    }
    else{
        alert("else");
        S[1].disabled=false;
        S[0].disabled=true;
    }*/

    /*
    var selectedSheet;
    var currentSheet;
    for (var i = 0; i < document.styleSheets.length; i++) {
        currentSheet = document.styleSheets[i];
        if (currentSheet.name === name) {
            selectedSheet = currentSheet.sheetObj;
            currentSheet.disabled = false;
        } else {
            currentSheet.disabled = true;
        }
    }
    return selectedSheet;
}*/



/*function swapstylesheet(sheet){
    document.getElementById('alternatif').setAttribute('href', sheet);
}*/
//"use strict";

/*
let btn = document.getElementById("bouttonstyle");
btn.addEventListener("click",updatestyle);

function updatestyle(){
   var styleSheetlist = document.styleSheets;
    if (styleSheetlist[0].disabled === true){
        styleSheetlist[0].disabled = false;
        styleSheetlist[1].disabled = true;
        document.getElementById("bouttonstyle").innerText="style principale";
    }
    else {
        styleSheetlist[0].disabled =true;
        styleSheetlist[1].disabled =false;
        document.getElementById("bouttonstyle").innerText="style alternatif";
    }
}
*/
/*
let date = new Date();
let langue =  navigator.language;
let lienmail = document.getElementById("mail");
if (langue=="fr"){
    let dateFr = date.getDate().toString().padStart(2,"0") + "-" + (date.getMonth()+1).toString().padStart(2,"0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();
    lienmail.href="mailto:fatimadabo@live.fr?subject=Page chargé le : " + dateFr;
}
else{
    let dateEn = (date.getMonth()+1).toString().padStart(2,"0") + "-" + date.getDate().toString().padStart(2,"0") + "-" + date.getFullYear() + ":" + date.getHours() + "h" + date.getMinutes();
    lienmail.href="mailto:fatimadabo@live.fr subject=Page chargé le : " + dateEn;
}
*/